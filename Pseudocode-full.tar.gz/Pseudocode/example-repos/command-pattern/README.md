# Command Pattern
Encapsulate actions as objects.

## Features
- Command execution
- Undo/redo support
- Command history
- Macro recording
- Multiple receivers
