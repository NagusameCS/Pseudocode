# LISP Interpreter
S-expression evaluator.

## Features
- Tokenizer
- Parser
- Evaluator
- Lambda functions
- Special forms (if, define, quote)
- Built-in arithmetic
