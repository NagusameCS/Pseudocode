# HTTP Client
Simple HTTP request library.

## Features
- GET, POST, PUT, DELETE
- URL parsing
- Query parameters
- Request builder pattern
- Response parsing
