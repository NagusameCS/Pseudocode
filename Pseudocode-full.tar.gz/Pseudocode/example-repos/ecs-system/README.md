# Entity Component System
Game architecture pattern for composition.

## Features
- Entity creation/destruction
- Component attachment
- Entity querying
- System registration
- Update loop
- Composition over inheritance
