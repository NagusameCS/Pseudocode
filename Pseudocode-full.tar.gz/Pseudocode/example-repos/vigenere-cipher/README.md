# Vigenere Cipher
Polyalphabetic substitution cipher.

## Features
- Encryption with key
- Decryption
- Case preservation
- Non-letter handling
