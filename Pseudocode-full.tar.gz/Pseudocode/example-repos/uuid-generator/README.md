# UUID Generator
Version 4 (random) UUID generation.

## Features
- UUID v4 generation
- Validation
- Version detection
- UUID parsing
