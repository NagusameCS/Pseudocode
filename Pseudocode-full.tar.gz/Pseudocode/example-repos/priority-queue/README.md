# Priority Queue
Binary min-heap implementation.

## Operations
- push: O(log n)
- pop: O(log n)
- peek: O(1)
