# Red-Black Tree

Self-balancing binary search tree with guaranteed O(log n) operations.

## Features

- Insert with automatic rebalancing
- Delete with fixup
- Search, min, max operations
- In-order traversal
- Tree validation
- Black height calculation

## Properties Maintained

1. Every node is red or black
2. Root is black
3. All leaves (NIL) are black
4. Red nodes have black children
5. All paths have equal black height

## Usage

```bash
./pseudo main.pseudo
```
