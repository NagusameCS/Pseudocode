# Bloom Filter

Space-efficient probabilistic data structure for set membership.

## Features

- Standard Bloom filter
- Counting Bloom filter (supports deletion)
- Optimal parameter calculation
- Multiple hash functions
- False positive rate estimation

## Usage

```bash
./pseudo main.pseudo
```

## Properties

- No false negatives (definite membership)
- Possible false positives
- O(k) time complexity (k = hash functions)
- Space efficient for large sets
