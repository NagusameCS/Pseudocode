# K-Means Clustering
Unsupervised machine learning.

## Features
- Euclidean distance
- Centroid initialization
- Iterative refinement
- Convergence detection
- Inertia calculation
