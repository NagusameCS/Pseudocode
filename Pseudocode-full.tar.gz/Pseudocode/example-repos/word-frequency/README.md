# Word Frequency
Text analysis and word counting.

## Features
- Tokenization
- Frequency counting
- Top N words
- Statistics (total, unique, avg length)
