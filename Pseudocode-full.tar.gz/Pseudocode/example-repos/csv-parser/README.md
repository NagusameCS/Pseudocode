# CSV Parser
Parse and manipulate CSV data.

## Features
- CSV parsing
- Quote handling
- Object conversion
- Column filtering
- Aggregation functions
