# Calendar
Calendar generation and date utilities.

## Features
- Month calendar display
- Leap year detection
- Day of week calculation
- Days in month
