# B-Tree
Self-balancing tree for databases.

## Features
- Multi-way search tree
- Node splitting
- Disk-optimized structure

## Complexity
- Search: O(log n)
- Insert: O(log n)
