# Bellman-Ford Algorithm

Single-source shortest paths with negative edge weights.

## Features

- Finds shortest paths from source to all vertices
- Handles negative edge weights
- Detects negative cycles
- Path reconstruction
- Early termination optimization

## Usage

```bash
./pseudo main.pseudo
```

## Complexity

- Time: O(V × E)
- Space: O(V)

## When to Use

| Algorithm | Negative Weights | Complexity |
|-----------|------------------|------------|
| Dijkstra | No | O((V+E)logV) |
| Bellman-Ford | Yes | O(VE) |
| Floyd-Warshall | Yes (all pairs) | O(V³) |

## Negative Cycles

A negative cycle allows infinite reduction of path cost.
The algorithm detects this by checking for updates in the Vth iteration.
