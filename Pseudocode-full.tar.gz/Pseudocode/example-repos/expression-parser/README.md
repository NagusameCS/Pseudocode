# Expression Parser

Recursive descent parser and evaluator for mathematical expressions.

## Features

- Tokenizer/Lexer
- Recursive descent parser
- AST generation
- Expression evaluation
- Variables support
- Built-in math functions
- Operator precedence

## Usage

```bash
./pseudo main.pseudo
```

## Supported Syntax

- Numbers: `42`, `3.14`
- Operators: `+`, `-`, `*`, `/`, `^`
- Parentheses: `(expr)`
- Variables: `x`, `y`, `pi`
- Functions: `sin`, `cos`, `sqrt`, `abs`, etc.

## Grammar

```
expr   -> term (('+' | '-') term)*
term   -> power (('*' | '/') power)*
power  -> unary ('^' power)?
unary  -> '-' unary | primary
```
