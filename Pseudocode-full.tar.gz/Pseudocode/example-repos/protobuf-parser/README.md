# Protocol Buffers Parser
Simple protobuf-like serialization.

## Features
- Schema definition
- Varint encoding
- Message encoding/decoding
- Wire types
- Enum support
