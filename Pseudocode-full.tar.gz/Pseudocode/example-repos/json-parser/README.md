# JSON Parser

A complete JSON parser and stringifier written from scratch.

## Features

- Recursive descent parser
- Supports all JSON types: null, boolean, number, string, array, object
- Escape sequence handling
- JSON stringifier for round-trip conversion
- Error reporting with position

## Usage

```bash
./pseudo main.pseudo
```

## Supported Types

| Type | Example |
|------|---------|
| null | `null` |
| boolean | `true`, `false` |
| number | `42`, `3.14`, `-1e10` |
| string | `"hello"` |
| array | `[1, 2, 3]` |
| object | `{"key": "value"}` |
