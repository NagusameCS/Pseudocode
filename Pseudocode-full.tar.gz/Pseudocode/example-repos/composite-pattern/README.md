# Composite Pattern
Tree structures with uniform interface.

## Features
- Leaf and composite nodes
- Recursive operations
- File system example
- Organization chart
- Tree statistics
