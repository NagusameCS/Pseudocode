# Run Length Encoding
Simple compression for repeated data.

## Features
- Array encoding
- String encoding
- Decoding
- Compression statistics
