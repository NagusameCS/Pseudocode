# Prim's Algorithm
Minimum Spanning Tree construction.

## Complexity
- Time: O(V²) with adjacency matrix
- Can be O(E log V) with priority queue
