# Poker Hand Evaluator
Texas Hold'em hand ranking.

## Features
- Deck creation and shuffling
- All hand rankings
- Flush and straight detection
- Hand comparison
- Multi-player game simulation
- Community card evaluation
