# Base64 Codec
Encode and decode base64.

## Features
- Encoding with padding
- Decoding
- Round-trip verification
