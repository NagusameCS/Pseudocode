# Snake Game

Classic snake game implementation with AI.

## Features

- Core game mechanics
- Wall and self-collision detection
- Food spawning
- Score tracking
- ASCII rendering
- Simple and smart AI players

## Usage

```bash
./pseudo main.pseudo
```

## Controls

| Key | Direction |
|-----|-----------|
| UP | Move up |
| DOWN | Move down |
| LEFT | Move left |
| RIGHT | Move right |

## Symbols

| Symbol | Meaning |
|--------|---------|
| `@` | Snake head |
| `o` | Snake body |
| `*` | Food |
