# Ray Tracer
Simple ray tracing renderer.

## Features
- Spheres and planes
- Point lights
- Shadow rays
- Diffuse shading
- ASCII visualization
