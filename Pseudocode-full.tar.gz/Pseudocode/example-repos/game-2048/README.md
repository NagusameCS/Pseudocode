# 2048 Game
Classic sliding puzzle game.

## Features
- 4x4 grid
- Tile merging
- Score tracking
- All 4 directions
- Win detection
