# Topological Sort

DAG vertex ordering with DFS and Kahn's algorithm.

## Features
- DFS-based topological sort
- Kahn's algorithm (BFS-based)
- Cycle detection

## Use Cases
- Task scheduling
- Build systems
- Course prerequisites
