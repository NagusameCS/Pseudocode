# Game of Life Advanced
Enhanced cellular automaton simulation.

## Features
- Board generation
- Pattern placement
- Generation evolution
- Multiple patterns
- Population tracking
