# Coin Change
Classic DP problem with multiple variants.

## Features
- Minimum coins needed
- Count number of ways
- Track coins used
