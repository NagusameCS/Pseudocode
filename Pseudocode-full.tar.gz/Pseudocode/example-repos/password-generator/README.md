# Password Generator
Secure password generation with options.

## Features
- Configurable length
- Character type selection
- Ambiguous character exclusion
- Passphrase generation
- PIN code generation
- Entropy calculation
