# Number Converter
Base conversion utilities.

## Features
- Binary conversions
- Hexadecimal conversions
- Octal conversions
- Decimal as intermediary
