# Database Index
B-Tree based database index implementation.

## Features
- B-tree structure
- Insert operations
- Exact key search
- Range queries
- Tree visualization
