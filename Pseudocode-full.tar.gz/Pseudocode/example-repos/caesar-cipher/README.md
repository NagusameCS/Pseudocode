# Caesar Cipher

Classical substitution cipher with frequency analysis cracking.

## Features

- Encrypt and decrypt with any shift
- ROT13 special case
- Frequency analysis attack
- Chi-squared scoring
- All 26 rotations display

## Usage

```bash
./pseudo main.pseudo
```

## How It Works

Each letter is shifted by a fixed amount:
- `A` with shift 3 becomes `D`
- `Z` with shift 3 becomes `C` (wraps around)
- Non-alphabetic characters unchanged

## Cracking

Frequency analysis compares letter frequencies in the ciphertext to expected English frequencies using chi-squared test.
