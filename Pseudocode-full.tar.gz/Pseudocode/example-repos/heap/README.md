# Heap (Priority Queue)

Min-heap and max-heap implementations with all standard operations.

## Features

- Min-heap and max-heap variants
- Insert, extract, peek operations
- Heapify from array
- Heap sort algorithm

## Usage

```bash
./pseudo main.pseudo
```

## Operations

| Operation | Time Complexity |
|-----------|----------------|
| Insert | O(log n) |
| Extract | O(log n) |
| Peek | O(1) |
| Heapify | O(n) |
| Heap Sort | O(n log n) |
