# AVL Tree
Self-balancing BST with O(log n) operations.

## Features
- Auto-balancing on insert
- Left/Right rotations
- Balance factor tracking
