# SemVer
Semantic versioning parser.

## Features
- Version parsing
- Comparison
- Version bumping
- Constraint matching
- Prerelease handling
