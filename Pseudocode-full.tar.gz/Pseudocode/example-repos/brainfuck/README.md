# Brainfuck Interpreter
Esoteric programming language.

## Features
- Full instruction set (+, -, <, >, [, ], ., ,)
- Memory cells (30000)
- I/O support
- Loop handling
- Jump table optimization
