# Diff/Patch
Myers diff algorithm for computing text differences.

## Features
- Line-by-line diff
- LCS-based algorithm
- Unified diff format
- Patch generation
- Statistics (insertions/deletions)
- Hunk grouping
