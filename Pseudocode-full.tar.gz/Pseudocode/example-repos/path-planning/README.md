# Path Planning
Navigation and route finding algorithms.

## Features
- Navigation mesh creation
- Waypoint connections
- A* pathfinding
- Grid-based navigation
- Obstacle handling
- Path visualization
