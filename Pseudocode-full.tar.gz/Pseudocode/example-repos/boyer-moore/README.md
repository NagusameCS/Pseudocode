# Boyer-Moore
Efficient string search algorithm.

## Features
- Bad character rule
- Right-to-left matching
- Sublinear performance
- Multiple matches
