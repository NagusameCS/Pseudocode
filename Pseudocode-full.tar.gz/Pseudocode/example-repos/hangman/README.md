# Hangman
Word guessing game.

## Features
- Word display with blanks
- Letter tracking
- ASCII art gallows
- Win/lose detection
- AI guessing strategy
