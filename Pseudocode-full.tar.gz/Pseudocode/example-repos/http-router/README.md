# HTTP Router

Pattern-based HTTP routing framework.

## Features

- Path parameter matching (`:id`)
- Wildcard matching (`*`)
- Query string parsing
- Middleware support
- Route groups
- Multiple HTTP methods

## Usage

```bash
./pseudo main.pseudo
```

## Patterns

| Pattern | Example Path | Params |
|---------|--------------|--------|
| `/users` | `/users` | `{}` |
| `/users/:id` | `/users/42` | `{id: "42"}` |
| `/api/:v/users` | `/api/v1/users` | `{v: "v1"}` |
| `/static/*` | `/static/js/app.js` | `{*: "js/app.js"}` |

## API

```pseudocode
router_get(router, pattern, handler)
router_post(router, pattern, handler)
router_use(router, middleware)
```
