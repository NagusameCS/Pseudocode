# Register VM
Virtual machine with registers.

## Features
- 8 general registers
- Arithmetic operations
- Conditional jumps
- Function calls
- Flags (zero, negative)
