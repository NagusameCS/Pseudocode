# Space Invaders
Classic arcade game simulation.

## Features
- Player movement and shooting
- Alien formations
- Bullet physics
- Collision detection
- Wave progression
- Score tracking
