# Big Integer
Arbitrary precision integer arithmetic.

## Features
- String representation
- Addition
- Multiplication
- Comparison
- Large factorials
