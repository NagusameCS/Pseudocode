# Connect Four
Two-player strategy game.

## Features
- 6x7 grid
- Gravity-based dropping
- Four-in-a-row detection
- Turn management
- Draw detection
