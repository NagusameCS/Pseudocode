# Scheduling Algorithm
Process scheduler implementations.

## Algorithms
- FCFS (First Come First Serve)
- SJF (Shortest Job First)
- Round Robin
- Priority Scheduling

## Features
- Process management
- Timeline visualization
- Statistics calculation
- Preemption support
