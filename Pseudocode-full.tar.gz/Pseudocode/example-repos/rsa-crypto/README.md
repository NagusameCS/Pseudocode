# RSA Cryptography
Simplified RSA encryption/decryption demo.

## Features
- Key pair generation
- Modular exponentiation
- Encryption/decryption
- Digital signatures
- Prime number finding
- Extended Euclidean algorithm
