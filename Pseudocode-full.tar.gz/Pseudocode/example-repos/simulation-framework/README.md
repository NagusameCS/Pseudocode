# Simulation Framework
Agent-based simulation system.

## Features
- Agent management
- Predator-prey dynamics
- State machines
- Spatial queries
- Population tracking
- ASCII visualization
