# ISBN Validator
ISBN-10 and ISBN-13 validation.

## Features
- ISBN-10 validation (with X check digit)
- ISBN-13 validation
- Auto-detect format
- ISBN-10 to ISBN-13 conversion
