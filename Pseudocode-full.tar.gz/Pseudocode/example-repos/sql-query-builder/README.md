# SQL Query Builder
Fluent interface for building SQL queries.

## Features
- SELECT with JOINs
- WHERE clauses
- INSERT, UPDATE, DELETE
- Prepared statement bindings
- GROUP BY, ORDER BY
