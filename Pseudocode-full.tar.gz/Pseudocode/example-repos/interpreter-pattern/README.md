# Interpreter Pattern
Simple expression language.

## Features
- Tokenization
- Recursive descent parsing
- Expression evaluation
- Variable substitution
- Operator precedence
