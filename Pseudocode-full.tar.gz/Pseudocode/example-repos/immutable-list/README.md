# Immutable List
Persistent functional data structure.

## Features
- Cons cells
- Head/tail access
- Map/filter/fold
- Append and reverse
- Take and drop
- Structural sharing
