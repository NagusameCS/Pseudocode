# Root Finding
Numerical methods for finding roots.

## Features
- Bisection method
- Newton-Raphson
- Secant method
- Fixed point iteration
- Convergence comparison
