# Type Checker
Hindley-Milner style type inference.

## Features
- Type variables
- Function types
- List types
- Unification
- Type inference
- Type schemes
