# Network Simulator
Packet routing and network simulation.

## Features
- Network topology modeling
- Dijkstra's routing
- Packet queuing
- Latency simulation
- Traffic statistics
- TTL handling
