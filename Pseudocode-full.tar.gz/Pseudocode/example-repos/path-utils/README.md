# Path Utilities
File path manipulation.

## Features
- dirname/basename
- Extension extraction
- Path joining
- Normalization
- Relative paths
