# Pong Game
Classic arcade game implementation.

## Features
- Ball physics
- Paddle controls
- Simple AI opponent
- Score tracking
- ASCII rendering
