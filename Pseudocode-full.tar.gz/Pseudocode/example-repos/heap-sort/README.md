# Heap Sort
In-place comparison sort using heap.

## Complexity
- Time: O(n log n)
- Space: O(1)

## Features
- Build heap in O(n)
- In-place sorting
- Not stable
