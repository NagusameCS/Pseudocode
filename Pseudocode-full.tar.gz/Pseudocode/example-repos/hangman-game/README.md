# Hangman Game
Word guessing game.

## Features
- Word guessing mechanics
- ASCII art hangman
- Letter tracking
- Win/lose detection
- Score calculation
- Multiple rounds
