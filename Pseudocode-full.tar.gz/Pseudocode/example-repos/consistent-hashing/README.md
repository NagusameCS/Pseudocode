# Consistent Hashing
Key distribution for distributed systems.

## Features
- Virtual nodes (replicas)
- Even distribution
- Minimal redistribution on node changes
