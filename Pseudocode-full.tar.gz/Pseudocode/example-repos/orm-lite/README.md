# ORM Lite
Simple Object-Relational Mapping.

## Features
- Model definition
- CRUD operations
- Relationships
- Query building
- Migration helpers
