# Neural Network

Feedforward neural network with backpropagation from scratch.

## Features

- Matrix operations library
- Activation functions (sigmoid, ReLU, tanh)
- Xavier weight initialization
- MSE loss function
- Backpropagation algorithm
- Configurable network architecture

## Usage

```bash
./pseudo main.pseudo
```

## Example

```pseudocode
// Create network: 2 input, 4 hidden, 1 output
let nn = create_network([2, 4, 1])

// Train on XOR problem
train(nn, inputs, targets, 1000, 0.5)

// Predict
let result = predict(nn, [1, 0])
```

## Architecture

Input Layer → Hidden Layer(s) → Output Layer
