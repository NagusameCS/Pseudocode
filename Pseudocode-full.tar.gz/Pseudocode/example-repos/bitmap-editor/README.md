# Bitmap Editor
Bitmap graphics editing tools.

## Features
- Line drawing (Bresenham)
- Rectangle/circle drawing
- Flood fill
- Undo/redo history
- Flip and invert
- ASCII rendering
