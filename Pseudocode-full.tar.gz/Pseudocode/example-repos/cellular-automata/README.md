# Cellular Automata
Conway's Game of Life and variations.

## Features
- Game of Life rules
- HighLife and Seeds variants
- Pattern loading
- Oscillator detection
- Still life detection
- Toroidal wrapping
