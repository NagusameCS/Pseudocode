# Argument Parser
Command line argument parsing.

## Features
- Long options (--name)
- Short options (-n)
- Flag combining (-abc)
- Value options (--name=value)
- Positional arguments
- Help generation
