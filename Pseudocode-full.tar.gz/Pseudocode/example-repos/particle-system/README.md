# Particle System
Physics-based particle simulation.

## Features
- Particle emitters
- Multiple forces
- Life/decay system
- Boundary collision
- ASCII visualization
