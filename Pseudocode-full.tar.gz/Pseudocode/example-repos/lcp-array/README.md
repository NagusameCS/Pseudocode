# LCP Array
Longest Common Prefix/Suffix.

## Features
- Common prefix finding
- Common suffix finding
- String comparison
- Array operations
