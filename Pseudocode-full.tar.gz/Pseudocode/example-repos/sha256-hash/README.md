# SHA-256 Hash
Simplified SHA-256 implementation.

## Features
- SHA-256-like hashing
- Hex output format
- Avalanche effect demo
- Hash verification
- Password hashing with salt
- HMAC implementation
