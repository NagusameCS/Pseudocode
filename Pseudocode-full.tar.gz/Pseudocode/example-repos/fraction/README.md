# Fraction Math
Exact fractional arithmetic with simplification.

## Features
- Automatic simplification
- Addition and subtraction
- Multiplication and division
- Power operations
- Decimal conversion
- Mixed number format
