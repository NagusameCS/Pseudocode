# Interval Tree
Range query data structure.

## Features
- Interval insertion
- Overlap detection
- Find all overlaps
- Range queries
