# Audio Synthesizer
Simple audio waveform generation.

## Features
- Multiple wave types
- ADSR envelope
- Note frequency calculation
- Waveform visualization
- Multi-oscillator mixing
