# Spell Checker
Word suggestion using edit distance.

## Features
- Levenshtein distance
- Dictionary lookup
- Suggestions ranking
- Text checking
