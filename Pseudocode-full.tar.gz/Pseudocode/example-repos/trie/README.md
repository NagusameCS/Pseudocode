# Trie (Prefix Tree)

Efficient prefix tree for string operations and autocomplete.

## Features

- Insert, search, delete words
- Prefix matching and counting
- Autocomplete with results limit
- Longest common prefix
- Spell checker with edit distance

## Usage

```bash
./pseudo main.pseudo
```

## Operations

| Operation | Time Complexity |
|-----------|----------------|
| Insert | O(m) |
| Search | O(m) |
| Prefix check | O(m) |
| Autocomplete | O(m + k) |

Where m = word length, k = results count
