# Event Emitter
Pub/sub pattern for event-driven programming.

## Features
- Subscribe (on)
- One-time listeners (once)
- Unsubscribe (off)
- Emit events with data
- Listener counting
