# Rate Limiter
Multiple rate limiting algorithms.

## Algorithms
- Token Bucket
- Sliding Window
- Fixed Window

## Use Cases
- API rate limiting
- Traffic shaping
- DDoS protection
