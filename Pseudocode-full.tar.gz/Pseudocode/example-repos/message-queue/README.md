# Message Queue
Producer/consumer message queue system.

## Features
- Priority queue
- Multiple consumers
- Retry mechanism
- Dead letter queue
- Queue statistics
- FIFO ordering
