# Pascal's Triangle
Generate and explore Pascal's triangle.

## Features
- Triangle generation
- Pretty printing
- Binomial coefficients
- Row sums
- Fibonacci from diagonals
