# Observable Pattern
Reactive programming basics.

## Features
- Observable creation
- Subscriptions
- Map/filter operators
- Error handling
- Completion signaling
