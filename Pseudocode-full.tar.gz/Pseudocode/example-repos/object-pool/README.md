# Object Pool
Resource pooling for expensive objects.

## Features
- Pre-allocation
- Acquire/release
- Pool size limits
- Resource reuse
- Statistics tracking
