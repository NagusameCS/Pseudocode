# FizzBuzz Variations
Classic and extended FizzBuzz.

## Features
- Classic FizzBuzz
- Customizable rules
- Functional style
- Statistics
