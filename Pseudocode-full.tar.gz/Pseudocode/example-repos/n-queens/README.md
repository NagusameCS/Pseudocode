# N-Queens Problem
Classic backtracking puzzle.

## Features
- All solutions finder
- Safety checking (row, diagonals)
- Board visualization
