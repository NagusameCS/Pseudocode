# Template Engine
Mustache-like template rendering.

## Features
- Variable interpolation
- Section loops
- Inverted sections
- Nested templates
- Comments
