# Asteroids
Classic arcade asteroid shooter.

## Features
- Ship rotation and thrust
- Wrap-around physics
- Bullet firing
- Asteroid splitting
- Collision detection
- Level progression
