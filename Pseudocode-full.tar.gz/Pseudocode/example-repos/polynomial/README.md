# Polynomial Operations
Polynomial arithmetic and calculus.

## Features
- Evaluation (Horner's method)
- Addition
- Multiplication
- Derivative
- Quadratic roots
- String representation
