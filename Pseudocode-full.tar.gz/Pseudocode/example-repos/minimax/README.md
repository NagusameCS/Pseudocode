# Minimax
Game AI with alpha-beta pruning.

## Features
- Minimax algorithm
- Alpha-beta pruning
- Tic-tac-toe implementation
- Optimal move finding
