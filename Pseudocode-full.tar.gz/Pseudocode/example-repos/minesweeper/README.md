# Minesweeper
Classic puzzle game.

## Features
- Configurable grid size
- Mine placement
- Flood reveal
- Flag toggling
- Win detection
