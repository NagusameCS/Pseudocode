# Maze Generator and Solver
DFS maze generation and A* solving.

## Features
- Random maze generation (DFS)
- DFS path finding
- A* pathfinding with heuristic
- Path visualization
- Variable maze sizes
- Wall/passage representation
