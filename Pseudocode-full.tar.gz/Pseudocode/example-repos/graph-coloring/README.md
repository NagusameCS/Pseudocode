# Graph Coloring
Vertex coloring algorithms.

## Features
- Greedy coloring
- Backtracking for chromatic number
- Safety checking
