# Email Validator
Email address validation and parsing.

## Features
- RFC-style validation
- Email parsing
- Normalization
- Masking
