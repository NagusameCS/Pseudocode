# Promise/Future
Async programming patterns.

## Features
- Promise creation
- Resolve/reject
- Then/catch handlers
- Promise.all/race/any
- Simulated async
