# INI Parser
Parse .ini configuration files.

## Features
- Section parsing
- Comment handling (;, #)
- Quoted value support
- INI generation
- Default values
