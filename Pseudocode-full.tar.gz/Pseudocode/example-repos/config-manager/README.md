# Config Manager
Configuration loading and management.

## Features
- Multiple sources (JSON, env)
- Nested key access
- Schema validation
- Default values
- Environment override
