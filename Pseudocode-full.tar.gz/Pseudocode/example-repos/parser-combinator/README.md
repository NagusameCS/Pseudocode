# Parser Combinator
Functional parser combinator library.

## Features
- Basic parsers (char, string, satisfy)
- Combinators (and, or, many)
- Map and transform
- Separated sequences
- Bracketed expressions
- Error handling
