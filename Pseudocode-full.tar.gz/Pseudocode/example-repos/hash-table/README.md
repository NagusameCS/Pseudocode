# Hash Table

A complete hash table implementation with open addressing and separate chaining.

## Features

- Two collision resolution strategies
- Dynamic resizing with load factor threshold
- String and numeric key support
- Get, set, delete, contains operations

## Usage

```bash
./pseudo main.pseudo
```

## Collision Resolution

1. **Separate Chaining** - Each bucket is a linked list
2. **Open Addressing** - Linear probing to find empty slots

## Operations

| Operation | Average | Worst |
|-----------|---------|-------|
| Insert | O(1) | O(n) |
| Search | O(1) | O(n) |
| Delete | O(1) | O(n) |
