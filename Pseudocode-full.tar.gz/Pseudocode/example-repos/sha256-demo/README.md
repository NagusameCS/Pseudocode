# SHA-256 Demo
Simplified cryptographic hashing.

## Features
- Hash computation
- Hexadecimal output
- Bit rotation
- Message processing
- Hash comparison
