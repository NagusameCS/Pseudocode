# Virtual DOM
Declarative UI rendering engine.

## Features
- Element creation (h function)
- Render to string
- Diffing algorithm
- Props diffing
- Children diffing
