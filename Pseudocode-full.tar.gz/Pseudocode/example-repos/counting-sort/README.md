# Counting Sort
Linear time sorting algorithms.

## Algorithms
- Counting Sort: O(n + k)
- Radix Sort: O(d(n + k))

## When to Use
- Integer keys
- Limited range of values
