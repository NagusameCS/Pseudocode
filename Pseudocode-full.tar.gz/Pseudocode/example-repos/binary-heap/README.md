# Binary Heap
Min-heap priority queue.

## Features
- Insert O(log n)
- Extract-min O(log n)
- Peek O(1)
- Heapify operations
