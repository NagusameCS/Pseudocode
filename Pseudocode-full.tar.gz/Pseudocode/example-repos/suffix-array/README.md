# Suffix Array
Efficient string data structure.

## Features
- Suffix array construction
- Binary search
- Pattern matching
- Occurrence counting
