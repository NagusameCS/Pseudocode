# Stack VM
Simple stack-based virtual machine.

## Features
- Stack operations
- Arithmetic ops
- Memory/variables
- Control flow
- Disassembler
