# Merge Sort

Divide and conquer sorting algorithm with O(n log n) time complexity.

## Features

- Top-down recursive merge sort
- Bottom-up iterative merge sort
- Stable sorting
- Analysis of comparisons and swaps

## Usage

```bash
./pseudo main.pseudo
```

## Complexity

| Case | Time | Space |
|------|------|-------|
| Best | O(n log n) | O(n) |
| Average | O(n log n) | O(n) |
| Worst | O(n log n) | O(n) |
