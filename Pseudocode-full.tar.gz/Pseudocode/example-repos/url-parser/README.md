# URL Parser
Parse and build URLs.

## Features
- Protocol extraction
- Query string parsing
- Fragment handling
- URL building
- URL encoding
