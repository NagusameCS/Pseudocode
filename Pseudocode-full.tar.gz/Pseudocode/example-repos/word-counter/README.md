# Word Counter
Text analysis and word frequency.

## Features
- Word and character counting
- Sentence detection
- Word frequency analysis
- Reading time estimation
- Flesch reading ease
- Syllable counting
