# Observable Pattern
Reactive programming primitives.

## Features
- Observable values
- Subscriptions
- Computed values
- Redux-like store
- Reducers
