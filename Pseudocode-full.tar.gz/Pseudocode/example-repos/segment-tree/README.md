# Segment Tree
Range queries and point updates in O(log n).

## Operations
- Build: O(n)
- Query: O(log n)
- Update: O(log n)
