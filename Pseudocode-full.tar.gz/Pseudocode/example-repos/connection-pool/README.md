# Connection Pool
Database connection pooling.

## Features
- Min/max pool size
- Acquire/release
- Query execution
- Health checks
- Pool statistics
