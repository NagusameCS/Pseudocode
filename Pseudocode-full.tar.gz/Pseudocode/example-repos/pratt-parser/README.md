# Pratt Parser
Top-down operator precedence parser.

## Features
- Prefix parselets
- Infix parselets
- Precedence levels
- Associativity control
- Function calls
- Expression evaluation
