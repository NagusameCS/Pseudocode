# Game of Life

Conway's Game of Life cellular automaton implementation.

## Features

- Toroidal grid (edges wrap around)
- Common patterns (Glider, Blinker, Block, Toad, R-pentomino)
- Generation stepping
- Live cell counting

## Usage

```bash
./pseudo main.pseudo
```

## Rules

1. Any live cell with 2-3 neighbors survives
2. Any dead cell with exactly 3 neighbors becomes alive
3. All other cells die or stay dead
