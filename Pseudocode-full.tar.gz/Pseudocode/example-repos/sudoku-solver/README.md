# Sudoku Solver

Backtracking solver with MRV optimization.

## Features

- Basic backtracking solver
- MRV (Minimum Remaining Values) heuristic
- Puzzle validation
- Puzzle generation
- Multiple difficulty levels

## Usage

```bash
./pseudo main.pseudo
```

## Algorithms

- **Basic**: Simple backtracking, tries 1-9 in order
- **MRV**: Chooses cell with fewest candidates first
- **Generation**: Creates valid puzzles by removing cells

## Difficulty Levels

| Level | Empty Cells |
|-------|-------------|
| Easy | ~35 |
| Medium | ~45 |
| Hard | ~55 |
