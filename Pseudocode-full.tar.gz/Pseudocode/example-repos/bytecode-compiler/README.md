# Bytecode Compiler
Compile source to bytecode.

## Features
- Opcode definitions
- Constant pool
- Variable allocation
- Jump resolution
- Disassembler
