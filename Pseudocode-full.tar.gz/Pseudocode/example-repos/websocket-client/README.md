# WebSocket Client
Event-driven WebSocket simulation.

## Features
- Connection management
- Send/receive messages
- Ping/pong heartbeat
- Auto-reconnection
- Frame encoding
