# LRU Cache

Least Recently Used cache implementation with O(1) operations.

## Features

- O(1) get and put operations
- Automatic eviction of least recently used items
- Configurable capacity
- Uses hash map + doubly linked list

## Usage

```bash
./pseudo main.pseudo
```

## Operations

| Operation | Time Complexity |
|-----------|----------------|
| Get | O(1) |
| Put | O(1) |
| Evict | O(1) |
