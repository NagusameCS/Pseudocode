# YAML Parser
Parse simple YAML documents.

## Features
- Key-value parsing
- List support
- Type inference
- YAML generation
- Comment handling
