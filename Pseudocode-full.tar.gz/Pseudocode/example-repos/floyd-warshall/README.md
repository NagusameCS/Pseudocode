# Floyd-Warshall Algorithm

All-pairs shortest paths in O(V³).

## Features
- Finds shortest paths between all vertex pairs
- Handles negative weights
- Detects negative cycles
- Path reconstruction

## Complexity
- Time: O(V³)
- Space: O(V²)
