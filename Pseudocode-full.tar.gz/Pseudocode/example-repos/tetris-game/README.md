# Tetris Game
Classic falling block puzzle game.

## Features
- 7 piece types (I, O, T, S, Z, J, L)
- Rotation system
- Line clearing
- Score & level tracking
- Collision detection
