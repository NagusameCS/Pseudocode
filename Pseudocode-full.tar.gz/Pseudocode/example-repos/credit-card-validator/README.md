# Credit Card Validator
Luhn algorithm and card type detection.

## Features
- Luhn validation
- Card type detection
- Number formatting
- Masking
- Check digit generation
