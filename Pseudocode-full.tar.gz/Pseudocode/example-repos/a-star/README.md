# A* Pathfinding

Optimal pathfinding algorithm with customizable heuristics.

## Features

- 4-directional and 8-directional movement
- Multiple heuristics (Manhattan, Euclidean, Chebyshev, Octile)
- Path visualization
- Obstacle handling
- Path cost calculation

## Usage

```bash
./pseudo main.pseudo
```

## Heuristics

| Heuristic | Best For |
|-----------|----------|
| Manhattan | 4-directional grids |
| Euclidean | Any-angle movement |
| Chebyshev | 8-dir, diagonal cost = 1 |
| Octile | 8-dir, diagonal cost = √2 |
