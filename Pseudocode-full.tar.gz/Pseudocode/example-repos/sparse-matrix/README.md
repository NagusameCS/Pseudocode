# Sparse Matrix
Efficient matrix storage.

## Features
- Dictionary-based storage
- Get/set operations
- Matrix addition
- Dense conversion
