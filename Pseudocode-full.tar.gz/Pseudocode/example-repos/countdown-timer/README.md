# Countdown Timer
Timer and countdown functionality.

## Features
- Countdown timer
- Time formatting
- Progress tracking
- Stopwatch with laps
- Pomodoro technique
- Multiple timer management
