# Physics Engine
Simple 2D physics simulation.

## Features
- Body dynamics
- Gravity and forces
- Elastic collisions
- Spring oscillation
- Energy conservation
