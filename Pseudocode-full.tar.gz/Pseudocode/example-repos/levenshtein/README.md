# Levenshtein Distance
Edit distance algorithm.

## Features
- Edit distance calculation
- Similarity ratio
- Spell checking
- Closest match finding
