# Cron Scheduler
Cron expression parser and job scheduler.

## Features
- Cron expression parsing
- Field types (any, value, range, step, list)
- Job management
- Time matching
- Next run calculation
- Job statistics
