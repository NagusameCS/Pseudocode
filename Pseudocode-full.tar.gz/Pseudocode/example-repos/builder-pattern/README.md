# Builder Pattern
Step-by-step object construction.

## Features
- Fluent interface
- Optional parameters
- Multiple builders
- Default values
- Complex object creation
