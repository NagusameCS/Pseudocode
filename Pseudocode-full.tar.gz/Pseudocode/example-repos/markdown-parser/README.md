# Markdown Parser

Converts Markdown to HTML.

## Features

- Headings (h1-h6)
- Bold and italic text
- Inline code
- Code blocks
- Links and images
- Ordered and unordered lists
- Blockquotes
- Horizontal rules
- HTML entity escaping

## Usage

```bash
./pseudo main.pseudo
```

## Supported Syntax

| Markdown | HTML |
|----------|------|
| `# Heading` | `<h1>` |
| `**bold**` | `<strong>` |
| `*italic*` | `<em>` |
| `` `code` `` | `<code>` |
| `[text](url)` | `<a href>` |
| `![alt](url)` | `<img>` |
| `- item` | `<ul><li>` |
| `1. item` | `<ol><li>` |
| `> quote` | `<blockquote>` |
