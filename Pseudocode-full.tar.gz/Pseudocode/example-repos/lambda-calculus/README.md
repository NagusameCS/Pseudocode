# Lambda Calculus Interpreter
Pure lambda calculus with Church encodings.

## Features
- Variable, abstraction, application
- Alpha conversion
- Beta reduction
- Normalization
- Church numerals
- Church booleans
