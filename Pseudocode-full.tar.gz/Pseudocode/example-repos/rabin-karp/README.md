# Rabin-Karp Algorithm

Rolling hash pattern matching.

## Features
- Rolling hash for efficient comparison
- Average O(n+m) time complexity
- Multiple pattern matching support

## Complexity
- Average: O(n + m)
- Worst: O(nm) with many hash collisions
