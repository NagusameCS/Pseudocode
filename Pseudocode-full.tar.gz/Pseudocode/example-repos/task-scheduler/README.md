# Task Scheduler
Cron-like job scheduling system.

## Features
- Interval-based jobs
- One-time jobs
- Job enable/disable
- Run statistics
- Tick simulation
