# Task Runner
Dependency-aware task execution system.

## Features
- Task dependencies
- Topological sorting
- Parallel execution groups
- Skip already executed
- Execution logging
- Circular dependency detection
