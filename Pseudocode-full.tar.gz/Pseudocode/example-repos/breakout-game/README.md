# Breakout Game
Classic brick breaker game.

## Features
- Ball physics
- Brick destruction
- Paddle control
- Score tracking
- Multiple lives
