# Strategy Pattern
Interchangeable algorithms.

## Features
- Algorithm encapsulation
- Runtime strategy change
- Sorting strategies
- Compression strategies
- Validation strategies
