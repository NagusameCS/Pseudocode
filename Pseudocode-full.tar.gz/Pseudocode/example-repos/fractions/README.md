# Fractions
Rational number arithmetic.

## Features
- Addition/subtraction
- Multiplication/division
- Reduction (GCD)
- Decimal conversion
- Comparison
