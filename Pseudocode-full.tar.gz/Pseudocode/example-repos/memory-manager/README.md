# Memory Manager
Virtual memory and paging simulation.

## Features
- Page table management
- LRU page replacement
- FIFO page replacement
- Dirty page tracking
- Page fault handling
- Statistics tracking
