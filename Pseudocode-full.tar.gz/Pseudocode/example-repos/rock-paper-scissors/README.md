# Rock Paper Scissors
Classic game simulation.

## Features
- Random play
- Win detection
- Series simulation
- AI counter-strategy
- Statistics
