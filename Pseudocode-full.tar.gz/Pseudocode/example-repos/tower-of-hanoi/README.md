# Tower of Hanoi
Classic recursive puzzle solver.

## Features
- Recursive solution
- Move generation
- Tower visualization
- Move counting
