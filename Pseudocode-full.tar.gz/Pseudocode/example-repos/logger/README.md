# Logger
Flexible logging framework.

## Features
- Log levels (TRACE to FATAL)
- Multiple handlers
- Contextual logging
- Child loggers
- Console and file output
