# Token Bucket Rate Limiter
Advanced rate limiting algorithms.

## Features
- Token bucket algorithm
- Sliding window counter
- Burst handling
- Wait time calculation
- Weighted requests
