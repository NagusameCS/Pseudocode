# Undo/Redo System
Command pattern with history management.

## Features
- Execute commands
- Undo/redo stacks
- History clearing
- State management
- Text editor example
