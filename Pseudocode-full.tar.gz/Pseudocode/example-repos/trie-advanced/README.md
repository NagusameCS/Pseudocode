# Trie (Advanced)
Prefix tree for efficient string operations.

## Features
- Insert/search/delete
- Prefix matching
- Autocomplete
- Word counting
- Frequency tracking
