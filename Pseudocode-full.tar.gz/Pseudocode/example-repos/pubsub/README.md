# PubSub System
Publish/subscribe event system.

## Features
- Topic management
- Subscriptions
- Message publishing
- Pattern matching
- Message history
- Statistics tracking
