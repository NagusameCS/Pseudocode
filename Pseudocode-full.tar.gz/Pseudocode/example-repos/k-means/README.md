# K-Means Clustering

K-Means clustering algorithm with K-Means++ initialization.

## Features

- K-Means++ smart initialization
- Configurable iterations and tolerance
- Within-cluster sum of squares (inertia)
- Silhouette score evaluation
- Elbow method demonstration

## Usage

```bash
./pseudo main.pseudo
```

## Algorithm

1. Initialize k centroids (random or K-Means++)
2. Assign each point to nearest centroid
3. Recalculate centroids as cluster means
4. Repeat until convergence
