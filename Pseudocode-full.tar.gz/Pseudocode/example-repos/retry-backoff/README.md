# Retry with Backoff
Resilient operation execution.

## Features
- Exponential backoff
- Configurable delays
- Jitter support
- Fallback operations
- Attempt tracking
