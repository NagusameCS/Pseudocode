# Tic-Tac-Toe with Minimax AI

Unbeatable tic-tac-toe AI using minimax algorithm.

## Features

- Complete game logic
- Win/draw detection
- Minimax algorithm with depth scoring
- AI vs Human simulation
- AI vs AI (perfect play)

## Usage

```bash
./pseudo main.pseudo
```

## Algorithm

The minimax algorithm explores all possible game states:
- Maximizing player tries to maximize score
- Minimizing player tries to minimize score
- Terminal states return +10 (win), -10 (loss), 0 (draw)
- Depth is used to prefer faster wins

## Perfect Play

When two optimal AIs play, the result is always a draw.
