# Regex Engine

Simple regular expression engine with basic pattern matching.

## Features

- Literal character matching
- Wildcard `.` (any character)
- Quantifiers: `*`, `+`, `?`
- Character classes: `[abc]`, `[a-z]`, `[^abc]`
- Anchors: `^`, `$`
- Find all matches
- Search and replace

## Usage

```bash
./pseudo main.pseudo
```

## Supported Syntax

| Pattern | Meaning |
|---------|---------|
| `.` | Any single character |
| `*` | Zero or more |
| `+` | One or more |
| `?` | Zero or one |
| `[abc]` | Character class |
| `[a-z]` | Character range |
| `[^abc]` | Negated class |
| `^` | Start anchor |
| `$` | End anchor |
