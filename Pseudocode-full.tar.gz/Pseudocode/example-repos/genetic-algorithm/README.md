# Genetic Algorithm
Optimization using evolutionary principles.

## Features
- Population evolution
- Tournament selection
- Crossover
- Mutation
- Fitness tracking
