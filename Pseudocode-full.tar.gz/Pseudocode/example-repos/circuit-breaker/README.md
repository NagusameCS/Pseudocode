# Circuit Breaker
Fault tolerance pattern implementation.

## Features
- Closed/Open/Half-open states
- Failure threshold
- Reset timeout
- Automatic recovery
- Call statistics
