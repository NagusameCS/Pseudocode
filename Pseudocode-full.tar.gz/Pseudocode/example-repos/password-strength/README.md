# Password Strength
Evaluate password security.

## Features
- Strength scoring
- Character type analysis
- Common pattern detection
- Entropy calculation
- Password generation
