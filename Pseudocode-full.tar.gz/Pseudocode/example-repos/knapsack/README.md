# Knapsack Problem
Multiple knapsack variants.

## Variants
- 0/1 Knapsack (DP)
- Unbounded Knapsack
- Fractional Knapsack (Greedy)

## Complexity
- 0/1: O(nW)
- Unbounded: O(nW)
- Fractional: O(n log n)
