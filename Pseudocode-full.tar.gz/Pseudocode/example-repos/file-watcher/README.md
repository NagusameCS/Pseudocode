# File Watcher
Monitor file system changes.

## Features
- Watch directories
- File event handlers
- Pattern filtering
- Recursive watching
- Change debouncing
