# Perlin Noise
Procedural noise generation.

## Features
- 2D Perlin noise
- Octave layering
- ASCII visualization
- Configurable scale
