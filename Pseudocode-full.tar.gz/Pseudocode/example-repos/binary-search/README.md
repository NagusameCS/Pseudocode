# Binary Search Variations
Multiple binary search implementations.

## Variants
- Standard binary search
- Lower/upper bound
- Rotated array search
- Peak finding
