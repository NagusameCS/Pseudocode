# Binary Search Tree

A complete binary search tree implementation in Pseudocode with all standard operations.

## Features

- Insert, search, delete operations
- Tree traversals (inorder, preorder, postorder, level-order)
- Find min/max, successor/predecessor
- Tree height and node counting
- Validate BST property

## Usage

```bash
./pseudo main.pseudo
```

## Operations

| Operation | Average | Worst |
|-----------|---------|-------|
| Insert | O(log n) | O(n) |
| Search | O(log n) | O(n) |
| Delete | O(log n) | O(n) |
| Traversal | O(n) | O(n) |
