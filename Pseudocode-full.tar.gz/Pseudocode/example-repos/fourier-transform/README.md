# Fourier Transform
Discrete Fourier Transform implementation.

## Features
- DFT computation
- Inverse DFT
- Frequency detection
- Spectrum visualization
