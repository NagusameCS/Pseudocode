# HTML Parser
Simple HTML tokenizing and DOM building.

## Features
- Tag tokenization
- Attribute parsing
- DOM tree construction
- Self-closing tags
- Text content extraction
