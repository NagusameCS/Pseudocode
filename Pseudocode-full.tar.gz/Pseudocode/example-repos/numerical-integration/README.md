# Numerical Integration
Approximate definite integrals.

## Features
- Rectangular rule
- Trapezoidal rule
- Simpson's rule
- Monte Carlo
- Romberg integration
