# Statistics
Descriptive statistics library.

## Features
- Mean, median, mode
- Variance, std deviation
- Quartiles, percentiles
- Z-scores
- Correlation
