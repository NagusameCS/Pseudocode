# Schema Validator
JSON schema validation.

## Features
- Type validation
- String constraints
- Number ranges
- Object properties
- Array validation
- Nested schemas
