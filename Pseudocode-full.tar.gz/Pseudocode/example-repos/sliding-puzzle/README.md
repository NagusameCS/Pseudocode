# Sliding Puzzle
Classic 15-puzzle implementation.

## Features
- Any NxN size
- Tile sliding
- Shuffle
- Solvability check
- Inversion counting
