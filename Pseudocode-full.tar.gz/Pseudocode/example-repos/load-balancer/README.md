# Load Balancer
Request distribution simulation.

## Algorithms
- Round Robin
- Weighted Round Robin
- Least Connections
- Least Response Time
- Random

## Features
- Server health checks
- Request statistics
- Dynamic server pool
- Response time tracking
