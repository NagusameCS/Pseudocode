# Blackjack
Casino card game.

## Features
- Full deck creation
- Card shuffling
- Hand evaluation
- Ace handling (1 or 11)
- Simple AI strategy
