# Blackjack Game
Card game with dealer AI.

## Features
- Full deck simulation
- Card shuffling
- Ace value adjustment
- Blackjack detection
- Dealer AI (hit on 16)
- Basic strategy player
