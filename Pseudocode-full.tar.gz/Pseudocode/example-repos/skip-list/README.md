# Skip List
Probabilistic data structure with O(log n) average operations.

## Features
- Fast search, insert, delete
- Probabilistic balancing
- Simple implementation
