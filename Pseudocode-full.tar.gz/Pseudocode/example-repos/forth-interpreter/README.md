# Forth Interpreter
Stack-based language interpreter.

## Features
- Stack manipulation
- Arithmetic operations
- Word definitions
- Comparison operators
- Dictionary lookup
