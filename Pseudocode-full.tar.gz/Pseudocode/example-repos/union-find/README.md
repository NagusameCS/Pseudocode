# Union-Find (Disjoint Set Union)

Efficient data structure for tracking connected components.

## Features

- Path compression optimization
- Union by rank/size
- Weighted Union-Find variant
- Kruskal's MST algorithm
- Cycle detection

## Usage

```bash
./pseudo main.pseudo
```

## Operations

| Operation | Time Complexity |
|-----------|-----------------|
| Find | O(α(n)) ≈ O(1) |
| Union | O(α(n)) ≈ O(1) |
| Connected | O(α(n)) ≈ O(1) |

α(n) is the inverse Ackermann function
