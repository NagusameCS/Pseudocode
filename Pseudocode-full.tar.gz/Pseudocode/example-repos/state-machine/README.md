# State Machine
Finite state machine implementation.

## Features
- State transitions
- Event validation
- Transition history
- Event listeners
- Available events query
