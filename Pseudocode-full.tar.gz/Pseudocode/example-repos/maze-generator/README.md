# Maze Generator
Generate and solve mazes.

## Features
- DFS maze generation
- Random maze layout
- Maze solving
- Path visualization
