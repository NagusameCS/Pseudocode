# Chess Engine
Chess game logic and simple AI.

## Features
- Full piece movement rules
- Move generation
- Capture detection
- Board evaluation
- Simple AI opponent
- Algebraic notation
