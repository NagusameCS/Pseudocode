# Decorator Pattern
Dynamic behavior extension.

## Features
- Text decorators
- Number transformations
- Coffee shop example
- Chained decorators
- Runtime composition
