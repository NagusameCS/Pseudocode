# K-D Tree
K-dimensional tree for spatial search.

## Features
- Point insertion
- Nearest neighbor search
- K-nearest neighbors
- Range search
- Multi-dimensional support
- Tree visualization
