# Flappy Bird Clone
Side-scrolling obstacle game.

## Features
- Gravity physics
- Jump/flap mechanics
- Procedural pipe generation
- Collision detection
- Score tracking
- Simple AI player
