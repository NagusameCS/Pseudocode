# Visitor Pattern
Separate algorithms from object structure.

## Features
- Double dispatch simulation
- Multiple visitors
- Tree traversal
- Result aggregation
- Type-specific handling
