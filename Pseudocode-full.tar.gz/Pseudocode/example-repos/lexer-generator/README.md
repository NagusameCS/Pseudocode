# Lexer Generator
Generate lexers from token definitions.

## Features
- Rule-based tokenization
- Keyword recognition
- Pattern matching
- Position tracking
- Whitespace handling
