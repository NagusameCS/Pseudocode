# Markov Chain
Text generation using Markov chains.

## Features
- Variable order chains
- Chain building
- Text generation
- Chain analysis
