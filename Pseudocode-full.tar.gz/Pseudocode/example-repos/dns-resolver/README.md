# DNS Resolver
Simple DNS query/response simulation.

## Features
- Zone management
- Record types (A, AAAA, MX, CNAME, NS)
- CNAME resolution
- Query caching
- TTL support
- Statistics tracking
