# Morse Code
Encode and decode Morse code.

## Features
- Text to Morse encoding
- Morse to text decoding
- Audio representation
- Full alphabet support
