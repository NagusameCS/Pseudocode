# Dijkstra's Algorithm

Shortest path algorithm for weighted graphs with non-negative edges.

## Features

- Adjacency list graph representation
- Priority queue based implementation
- Path reconstruction
- Distance calculation

## Usage

```bash
./pseudo main.pseudo
```

## Complexity

| Operation | Time Complexity |
|-----------|----------------|
| Dijkstra | O((V + E) log V) |
| Path Reconstruction | O(V) |
