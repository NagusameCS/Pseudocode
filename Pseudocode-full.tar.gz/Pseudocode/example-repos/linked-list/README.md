# Linked List

A complete singly and doubly linked list implementation in Pseudocode.

## Features

- Singly linked list with all standard operations
- Doubly linked list for bidirectional traversal
- Insert, delete, search, reverse operations
- Pretty printing for visualization

## Usage

```bash
./pseudo main.pseudo
```

## Operations

| Operation | Time Complexity |
|-----------|----------------|
| Insert at head | O(1) |
| Insert at tail | O(n) / O(1)* |
| Delete | O(n) |
| Search | O(n) |
| Reverse | O(n) |

*O(1) with tail pointer
