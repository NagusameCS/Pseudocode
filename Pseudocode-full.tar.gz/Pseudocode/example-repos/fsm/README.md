# Finite State Machine
Generic FSM implementation.

## Features
- State definitions
- Transition guards
- Actions and effects
- Event listeners
- State history
- Visualization
