# Matrix Operations
Comprehensive matrix math library.

## Features
- Multiplication, transpose
- Determinant (recursive)
- Matrix exponentiation
- Identity matrix
