# Garbage Collector
Mark and sweep garbage collection.

## Features
- Mark phase
- Sweep phase
- Root tracking
- Cycle detection
- Statistics reporting
