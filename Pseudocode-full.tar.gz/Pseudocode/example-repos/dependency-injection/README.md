# Dependency Injection
IoC container implementation.

## Features
- Singleton services
- Transient services
- Direct instances
- Factory functions
- Dependency resolution
