# Decision Tree
Simple decision tree classifier.

## Features
- Gini impurity
- Recursive splitting
- Prediction
- Tree visualization
