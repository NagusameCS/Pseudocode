# KMP String Matching

Knuth-Morris-Pratt pattern matching in O(n+m).

## Features
- Linear time pattern matching
- LPS (Longest Proper Prefix Suffix) array
- Multiple match detection

## Complexity
- Preprocessing: O(m)
- Searching: O(n)
- Total: O(n + m)
