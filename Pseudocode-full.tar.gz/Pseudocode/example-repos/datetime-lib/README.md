# Date/Time Library
Date manipulation utilities.

## Features
- Date creation
- Leap year detection
- Day of week calculation
- Date arithmetic
- Formatting/parsing
