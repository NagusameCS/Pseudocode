# LZ77 Compression
Sliding window compression algorithm.

## Features
- LZ77 sliding window
- Longest match finding
- Literal and reference tokens
- Run-length encoding
- Compression ratio calculation
- Lossless round-trip
