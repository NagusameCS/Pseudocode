# Quadtree
Spatial partitioning data structure.

## Features
- Point insertion
- Automatic subdivision
- Range queries
- Radius queries
- Tree statistics
- ASCII visualization
