# Huffman Coding

Optimal prefix-free compression.

## Features
- Frequency analysis
- Huffman tree construction
- Encoding and decoding
- Compression ratio calculation

## How It Works
1. Count character frequencies
2. Build tree from lowest frequency nodes
3. Assign codes based on tree path
4. Encode using variable-length codes
