# Memory Allocator
Custom memory management simulation.

## Features
- First-fit allocation
- Block coalescing
- Reallocation
- Memory visualization
- Usage statistics
