# Fenwick Tree (BIT)
Binary Indexed Tree for prefix sums.

## Features
- Prefix sum queries: O(log n)
- Point updates: O(log n)
- Space: O(n)
