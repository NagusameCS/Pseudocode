# Image Processing
Basic image manipulation library.

## Features
- Grayscale conversion
- Brightness adjustment
- Edge detection
- Blur filter
- Line/rect drawing
