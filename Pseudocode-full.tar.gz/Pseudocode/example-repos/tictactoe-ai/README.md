# Tic Tac Toe AI
Unbeatable AI using minimax.

## Features
- Perfect play with minimax
- Alpha-beta pruning
- Win/draw detection
- Random opponent
- AI vs AI matches
- Game statistics
