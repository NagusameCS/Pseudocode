# Diff Algorithm
Text difference computation using LCS.

## Features
- Line-based diff
- LCS algorithm
- Change formatting
- Patch application
- Statistics
