# Simple Neural Network
Basic feedforward neural network.

## Features
- XOR problem training
- Sigmoid activation
- Backpropagation
- Matrix operations
