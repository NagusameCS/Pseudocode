# Linguist Submission for Pseudocode Language

This folder contains the necessary files for submitting Pseudocode to GitHub Linguist for official language recognition.

## Files

- `Pseudocode.tmLanguage` - TextMate grammar in plist format (required by Linguist)
- `languages.yml` - Entry to add to Linguist's languages.yml
- `samples/` - Sample files demonstrating language features

## Requirements for Linguist Acceptance

1. **200+ unique repositories** using the language
2. **Well-documented grammar** in TextMate plist format
3. **Sample files** showing language variety
4. **Unique file extension** (`.pseudo`)

## Submission Process

1. Fork [github/linguist](https://github.com/github/linguist)
2. Add `Pseudocode.tmLanguage` to `grammars/`
3. Add entry from `languages.yml` to `lib/linguist/languages.yml`
4. Add samples to `samples/Pseudocode/`
5. Open pull request

## Grammar Features

The TextMate grammar supports:
- Single-line comments (`//`)
- String literals (single and double quoted)
- Numeric literals (integer, float, hex, binary)
- Keywords (`fn`, `let`, `if`, `for`, `while`, `match`, etc.)
- Block delimiters (`then`, `do`, `end`)
- 80+ built-in functions
- Logical operators (`and`, `or`, `not`)

## Color

Suggested color: `#4a90d9` (blue)

## See Also

- [Pseudocode Language Repository](https://github.com/pseudocode-lang/Pseudocode)
- [VS Code Extension](https://marketplace.visualstudio.com/items?itemName=NagusameCS.pseudocode-lang)
- [Language Specification](../docs/SPEC.md)
