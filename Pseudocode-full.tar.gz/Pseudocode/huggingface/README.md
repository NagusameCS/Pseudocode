# Pseudocode Language Training Dataset

This folder contains training data for AI models to learn the Pseudocode programming language.

## Dataset Structure

- `pseudocode_examples.jsonl` - Instruction/response pairs for fine-tuning
- `pseudocode_corpus.txt` - Raw code corpus for pretraining
- `pseudocode_qa.jsonl` - Question/answer pairs about the language
- `pseudocode_docs.jsonl` - Documentation snippets

## Format

JSONL files contain one JSON object per line:

```json
{"instruction": "...", "response": "...", "category": "..."}
```

## Categories

- `syntax` - Basic language syntax questions
- `algorithms` - Algorithm implementations
- `data_structures` - Data structure implementations
- `builtins` - Built-in function usage
- `patterns` - Common coding patterns
- `debugging` - Error fixing and debugging

## Usage

### Hugging Face Hub

```python
from datasets import load_dataset

dataset = load_dataset("pseudocode-lang/pseudocode-training")
```

### Fine-tuning

This dataset is suitable for:
- Instruction fine-tuning of LLMs
- Code completion model training
- Code understanding tasks

## License

MIT License - see main repository
