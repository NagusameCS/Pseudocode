# Rosetta Code Examples in Pseudocode

This folder contains implementations of classic programming tasks from [Rosetta Code](https://rosettacode.org) written in the Pseudocode language.

## Available Tasks

| File | Description |
|------|-------------|
| [100-doors.pseudo](100-doors.pseudo) | The 100 doors problem |
| [ackermann.pseudo](ackermann.pseudo) | Ackermann function |
| [binary-search.pseudo](binary-search.pseudo) | Binary search algorithm |
| [bubble-sort.pseudo](bubble-sort.pseudo) | Bubble sort algorithm |
| [factorial.pseudo](factorial.pseudo) | Factorial computation |
| [fibonacci.pseudo](fibonacci.pseudo) | Fibonacci sequence |
| [fizzbuzz.pseudo](fizzbuzz.pseudo) | FizzBuzz problem |
| [gcd.pseudo](gcd.pseudo) | Greatest common divisor |
| [happy-numbers.pseudo](happy-numbers.pseudo) | Happy number detection |
| [levenshtein-distance.pseudo](levenshtein-distance.pseudo) | Edit distance calculation |
| [palindrome.pseudo](palindrome.pseudo) | Palindrome detection |
| [quicksort.pseudo](quicksort.pseudo) | Quicksort algorithm |
| [roman-numerals.pseudo](roman-numerals.pseudo) | Roman numeral conversion |
| [sieve-of-eratosthenes.pseudo](sieve-of-eratosthenes.pseudo) | Prime number sieve |
| [towers-of-hanoi.pseudo](towers-of-hanoi.pseudo) | Towers of Hanoi puzzle |

## Running

```bash
./pseudo <filename>.pseudo
```

## Contributing to Rosetta Code

To add Pseudocode to Rosetta Code:

1. Visit [Rosetta Code](https://rosettacode.org)
2. Find a task page
3. Add a "Pseudocode" section with your implementation
4. Format code using `<syntaxhighlight lang="text">` (until proper highlighting is added)

## Language Features Demonstrated

- Functions with `fn` keyword
- Control flow: `if/elif/else/end`, `for/in/to/do/end`, `while/do/end`
- Pattern matching: `match/case/then/end`
- Dictionaries and arrays
- Recursion and memoization
- Built-in functions: `len`, `str`, `sqrt`, `abs`, etc.
